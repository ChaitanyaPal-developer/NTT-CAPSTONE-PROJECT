#!/usr/bin/env python3
"""Two-pass assembler for the Hack computer (Nand2Tetris).

K = 62, so K mod 3 = 2: duplicate-label warnings are enabled.
Usage: python assembler.py Box.asm
"""
from pathlib import Path
import re
import sys

PREDEFINED = {
    "SP": 0, "LCL": 1, "ARG": 2, "THIS": 3, "THAT": 4,
    "SCREEN": 16384, "KBD": 24576,
}
for i in range(16):
    PREDEFINED[f"R{i}"] = i

COMP = {
    "0": "0101010", "1": "0111111", "-1": "0111010",
    "D": "0001100", "A": "0110000", "M": "1110000",
    "!D": "0001101", "!A": "0110001", "!M": "1110001",
    "-D": "0001111", "-A": "0110011", "-M": "1110011",
    "D+1": "0011111", "A+1": "0110111", "M+1": "1110111",
    "D-1": "0001110", "A-1": "0110010", "M-1": "1110010",
    "D+A": "0000010", "D+M": "1000010",
    "D-A": "0010011", "D-M": "1010011",
    "A-D": "0000111", "M-D": "1000111",
    "D&A": "0000000", "D&M": "1000000",
    "D|A": "0010101", "D|M": "1010101",
}
DEST = {
    "": "000", "M": "001", "D": "010", "MD": "011",
    "A": "100", "AM": "101", "AD": "110", "AMD": "111",
}
JUMP = {
    "": "000", "JGT": "001", "JEQ": "010", "JGE": "011",
    "JLT": "100", "JNE": "101", "JLE": "110", "JMP": "111",
}
SYMBOL_RE = re.compile(r"^[A-Za-z_.$:][A-Za-z0-9_.$:]*$")


class AssemblyError(Exception):
    pass


def read_source(path):
    """Return (original_line_number, cleaned_instruction) pairs."""
    result = []
    with open(path, "r", encoding="utf-8") as source:
        for line_no, raw in enumerate(source, 1):
            instruction = raw.split("//", 1)[0].strip()
            if instruction:
                result.append((line_no, instruction))
    return result


def first_pass(lines):
    symbols = PREDEFINED.copy()
    rom_address = 0
    label_names = set()

    for line_no, instruction in lines:
        if instruction.startswith("(") or instruction.endswith(")"):
            if not (instruction.startswith("(") and instruction.endswith(")")):
                raise AssemblyError(f"Line {line_no}: malformed label")
            label = instruction[1:-1].strip()
            if not SYMBOL_RE.fullmatch(label):
                raise AssemblyError(f"Line {line_no}: invalid label")
            if label in label_names or label in PREDEFINED:
                # K = 62 => feature 2: warn on repeated label declarations.
                print(f"Warning: Line {line_no}: duplicate label '{label}'")
            else:
                symbols[label] = rom_address
                label_names.add(label)
        else:
            rom_address += 1
            if rom_address > 32768:
                raise AssemblyError(f"Line {line_no}: program exceeds ROM32K")
    return symbols


def assemble(path):
    lines = read_source(path)
    symbols = first_pass(lines)
    next_variable = 16
    machine_code = []

    for line_no, instruction in lines:
        if instruction.startswith("(") and instruction.endswith(")"):
            continue

        try:
            if instruction.startswith("@"):
                symbol = instruction[1:].strip()
                if not symbol:
                    raise ValueError("missing A-instruction value")
                if symbol.isdecimal():
                    address = int(symbol)
                else:
                    if not SYMBOL_RE.fullmatch(symbol):
                        raise ValueError("invalid symbol")
                    if symbol not in symbols:
                        symbols[symbol] = next_variable
                        next_variable += 1
                    address = symbols[symbol]
                if not 0 <= address <= 32767:
                    raise ValueError("A-instruction value must be 0..32767")
                machine_code.append(f"{address:016b}")
                continue

            if instruction.count("=") > 1 or instruction.count(";") > 1:
                raise ValueError("invalid C-instruction syntax")

            if ";" in instruction:
                left, jump = instruction.split(";", 1)
            else:
                left, jump = instruction, ""

            if "=" in left:
                dest, comp = left.split("=", 1)
            else:
                dest, comp = "", left

            dest, comp, jump = dest.strip(), comp.strip(), jump.strip()
            if dest not in DEST:
                raise ValueError(f"invalid destination '{dest}'")
            if comp not in COMP:
                raise ValueError(f"invalid computation '{comp}'")
            if jump not in JUMP:
                raise ValueError(f"invalid jump '{jump}'")

            machine_code.append("111" + COMP[comp] + DEST[dest] + JUMP[jump])

        except ValueError as exc:
            raise AssemblyError(f"Line {line_no}: {exc}") from exc

    return machine_code, symbols


def main():
    if len(sys.argv) != 2:
        print("Usage: python assembler.py <file.asm>")
        return 2

    source_path = Path(sys.argv[1])
    try:
        code, symbols = assemble(source_path)
        output_path = source_path.with_suffix(".hack")
        output_path.write_text("\\n".join(code) + "\\n", encoding="utf-8")
        print(f"Assembly successful: {output_path} ({len(code)} instructions)")
        return 0
    except (OSError, AssemblyError) as exc:
        print(f"Assembly failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
