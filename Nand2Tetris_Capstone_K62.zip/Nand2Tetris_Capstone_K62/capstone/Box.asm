// Nand2Tetris Capstone: Make the Computer Draw a Box
// Personal number K = 62
// Start row = 62; height = 20 rows; width = 48 pixels = 3 words.
// One screen row is 32 words. SCREEN + 32*62 = 18368.

(LOOP)
    @KBD
    D=M
    @BLACK
    D;JNE

// No key: choose white (0).
    @R15
    M=0
    @DRAW
    0;JMP

// Key pressed: choose black (-1).
(BLACK)
    @R15
    M=-1

(DRAW)
    @18368
    D=A
    @R13
    M=D

    @20
    D=A
    @R14
    M=D

(ROW)
    // Word 1
    @R15
    D=M
    @R13
    A=M
    M=D

    // Word 2
    @R13
    M=M+1
    @R15
    D=M
    @R13
    A=M
    M=D

    // Word 3
    @R13
    M=M+1
    @R15
    D=M
    @R13
    A=M
    M=D

    // Three words were written. Add 29 more to advance 32 words total.
    @29
    D=A
    @R13
    M=D+M

    // Decrement row count and repeat while positive.
    @R14
    M=M-1
    D=M
    @ROW
    D;JGT

    @LOOP
    0;JMP
