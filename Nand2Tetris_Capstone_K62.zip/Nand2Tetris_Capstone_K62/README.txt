NAND2TETRIS CAPSTONE — K=62
================================

Personal number:
  K = 62
  K mod 4 = 2 => width = 16*(2+1) = 48 pixels = 3 words
  K mod 3 = 2 => warn about duplicate labels
  Starting row = 62
  Height = 20 rows
  Start address = SCREEN + 32*62 = 16384 + 1984 = 18368

FILES
-----
capstone/CPU.hdl       CPU integration
capstone/Memory.hdl    RAM/Screen/Keyboard memory map
capstone/Computer.hdl  ROM + CPU + Memory
capstone/assembler.py  Two-pass Hack assembler
capstone/Box.asm       K=62 rectangle program
capstone/Box.hack      Generated machine code

RUN
---
From the capstone directory:
  python assembler.py Box.asm

This creates Box.hack. Python 3 is required.

IMPORTANT TESTING NOTES
----------------------
1. Open the HDL files in the Nand2Tetris Hardware Simulator.
2. The CPU/Memory/Computer chips use standard built-in Nand2Tetris chips
   such as ALU, Register, PC, RAM16K, Screen, Keyboard, ROM32K and gates.
3. Run the official supplied .tst files. Fix any simulator or integration
   errors before claiming a test passed.
4. Compare assembler output for Add, Max, Rect and Pong with the official
   assembler. Those .asm test programs must be available locally.
5. Load Box.hack in the CPU Emulator. Press a key in the keyboard panel to
   draw; release it to clear.
6. Capture your own screenshots. This package does not fabricate test results.

BOX ADDRESS MATH
----------------
Each screen row contains 32 words; each word contains 16 pixels.
Row 62 begins at 16384 + (32*62) = 18368.
Each box row writes 3 words, then advances a further 29 words:
3 + 29 = 32 words per screen row.
